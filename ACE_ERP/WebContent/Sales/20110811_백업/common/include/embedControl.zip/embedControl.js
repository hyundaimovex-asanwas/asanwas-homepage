function __WS__(__NSID__)
{
	document.write( __NSID__.innerHTML );
	__NSID__.id = "";
}
